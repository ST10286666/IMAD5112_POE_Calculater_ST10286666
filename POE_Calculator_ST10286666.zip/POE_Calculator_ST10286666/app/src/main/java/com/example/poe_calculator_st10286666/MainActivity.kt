package com.example.poe_calculator_st10286666

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        addingtwonumbers()
    }
    fun addingtwonumbers()
    {
        var num1 = findViewById<EditText>(R.id.InputNumber1)
        var num2 =  findViewById<EditText>(R.id.InputNumber2)
        var Additonbutton = findViewById<Button>(R.id.AdditonButton)
        var MultiplyButton = findViewById<Button>(R.id.MultiplyButton)
        var OutputDisplay = findViewById<TextView>(R.id.OutputDisplay)
        var DivideButton = findViewById<Button>(R.id.DivideButton)
        var SubtractButton = findViewById<Button>(R.id.SubtractButton)

        Additonbutton.setOnClickListener {
            var addnum1 = num1.text.toString().toInt()
            var addnum2 = num2.text.toString().toInt()
            var result = addnum1 + addnum2
            OutputDisplay.text = result.toString()

        }
        MultiplyButton.setOnClickListener {
            var addnum1 = num1.text.toString().toInt()
            var addnum2 = num2.text.toString().toInt()
            var resultmultiply = addnum1 * addnum2
            OutputDisplay.text = resultmultiply.toString()

        }
        DivideButton.setOnClickListener {
            var addnum1 = num1.text.toString().toInt()
            var addnum2 = num2.text.toString().toInt()
            var resultDivide = addnum1 / addnum2
            OutputDisplay.text = resultDivide.toString()

        }
        SubtractButton.setOnClickListener {
            var addnum1 = num1.text.toString().toInt()
            var addnum2 = num2.text.toString().toInt()
            var resultsubtract = addnum1 - addnum2
            OutputDisplay.text = resultsubtract.toString()
        }
    }


}